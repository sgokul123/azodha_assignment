import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../model/movie_model.dart';

enum MovieEvent { fetchMovies }

// Define the states
class MovieState {
  final List<MovieModel> movies;
  final bool isLoading;
  final String errorMessage;

  MovieState({
    required this.movies,
    required this.isLoading,
    this.errorMessage = '',
  });

  factory MovieState.initial() {
    return MovieState(movies: [], isLoading: false);
  }

  factory MovieState.loading() {
    return MovieState(movies: [], isLoading: true);
  }

  factory MovieState.success(List<MovieModel> movies) {
    return MovieState(movies: movies, isLoading: false);
  }

  factory MovieState.failure(String errorMessage) {
    return MovieState(movies: [], isLoading: false, errorMessage: errorMessage);
  }
}

class MovieBloc extends Bloc<MovieEvent, MovieState> {
  MovieBloc() : super(MovieState.initial());

  @override
  Stream<MovieState> mapEventToState(MovieEvent event) async* {
    if (event == MovieEvent.fetchMovies) {
      yield MovieState.loading();
      try {
        final List<MovieModel> movies = await fetchMovies();
        print("fetchMovies");
        yield movies.isNotEmpty
            ? MovieState.success(movies)
            : MovieState.failure("Failed to load movies:");
      } catch (_) {
        yield MovieState.failure("Failed to load movies:");
      }
    }
  }

  Future<List<MovieModel>> fetchMovies() async {
    print("fetchMovies");
    List<MovieModel> movies = [];
    movies.add(MovieModel(
        title: "Friends",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "22mins",
        rating: "PG",
        starRating: 4.8,
        releaseDate: "September22,1994"));
    movies.add(MovieModel(
        title: "Avatar",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "2hour 15 mins",
        rating: "12A",
        starRating: 4.9,
        releaseDate: "October 10, 1994"));
    movies.add(MovieModel(
        title: "Solanki",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "45 mins",
        rating: "18+",
        starRating: 4.6,
        releaseDate: "July 10, 1994"));
    movies.add(MovieModel(
        title: "Divya",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "45 mins",
        rating: "18+",
        starRating: 4.6,
        releaseDate: "July 10, 1994"));
    movies.add(MovieModel(
        title: "SAvatra",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "45 mins",
        rating: "18+",
        starRating: 4.6,
        releaseDate: "July 10, 1994"));
    movies.add(MovieModel(
        title: "Dexter",
        description:
            "Daredevil: Matt Murdock, a blind lawyer by day and vigilante by night, tries to protect Hell\'s Kitchen with his enhanced abilities as Daredevil outside the system while also trying to live a (somewhat) normal life as a lawyer working within the bounds of the law...",
        duration: "45 mins",
        rating: "18+",
        starRating: 4.6,
        releaseDate: "July 10, 1994"));
    return movies;
  }
}
