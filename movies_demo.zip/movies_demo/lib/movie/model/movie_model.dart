class MovieModel {
  String? title;
  String? rating;
  String? releaseDate;
  String? duration;
  String? description;
  double? starRating;

  MovieModel({this.title, this.rating, this.releaseDate, this.duration,
    this.description, this.starRating});

  factory MovieModel.fromJson(Map<String, dynamic> json) {
    return MovieModel(
      title: json["title"],
      rating: json["rating"],
      releaseDate: json["releaseDate"],
      duration: json["duration"],
      description: json["description"],
      starRating: double.parse(json["starRating"]),
    );
  }
//
}
