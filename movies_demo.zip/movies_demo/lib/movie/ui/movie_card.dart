import 'package:flutter/material.dart';

import '../model/movie_model.dart';

class MovieCard extends StatelessWidget {
  final MovieModel movieModel;
  final Function callBack;

  const MovieCard({
    super.key,
    required this.movieModel,
    required this.callBack,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        callBack();
      },
      child: Card(
        child: ListTile(
          leading: Image.asset("images/avatar.jpeg"),
          title: Text(movieModel.title ?? ""),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("${movieModel.rating} | ${movieModel.releaseDate}"),
              Text(movieModel.duration ?? ""),
            ],
          ),
          trailing: Container(
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              color: Colors.amber,
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.star,
                  color: Colors.white,
                  size: 16,
                ),
                const SizedBox(
                  width: 4.0,
                ),
                Text(
                  "${movieModel.starRating ?? ""}",
                  style: const TextStyle(color: Colors.white),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
