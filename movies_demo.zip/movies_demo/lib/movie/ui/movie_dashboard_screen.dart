import 'dart:convert';
import 'dart:core';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:movies_demo/movie/model/movie_model.dart';

import '../block/movie_bloc.dart';
import 'movie_card.dart';
import 'movie_details_screen.dart';

class MovieDashboardPage extends StatefulWidget {
  const MovieDashboardPage({super.key});

  @override
  State<MovieDashboardPage> createState() => _MovieDashboardPageState();
}

class _MovieDashboardPageState extends State<MovieDashboardPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Container(
          color: Colors.blue,
          child: const Drawer(
            backgroundColor: Colors.blue,
            elevation: 10.0,
            child: SizedBox(),
          ),
        ),
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: const Text(""),
        ),
        body: BlocProvider(
          create: (context) => MovieBloc()..add(MovieEvent.fetchMovies),
          child: BlocBuilder<MovieBloc, MovieState>(
            builder: (context, state) {
              print("state : ${state}");
              if (state.isLoading) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              } else if (state.errorMessage.isNotEmpty) {
                return Center(
                  child: Text(state.errorMessage),
                );
              } else {
                List<MovieModel> movieList = state.movies;
                print("state : ${movieList.length}");
                return movieList.isNotEmpty
                    ? ListView.builder(
                        itemCount: movieList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return MovieCard(
                            movieModel: movieList[index],
                            callBack: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => MovieDetailsPage(
                                          movieModel: movieList[index],
                                        )),
                              );
                            },
                          );
                        },
                      )
                    : const Center(
                        child: Text('Failed to load movies.'),
                      );
              }
            },
          ),
        ),
      ),
    );
  }
}
